# Betamorphosi
# DEBIAN 10 LTS


install script
apt update && apt upgrade -y && apt install -y bzip2 gzip coreutils screen curl && wget https://raw.githubusercontent.com/kotajakarta/script/main/setup.sh && chmod +x setup.sh && ./setup.sh
